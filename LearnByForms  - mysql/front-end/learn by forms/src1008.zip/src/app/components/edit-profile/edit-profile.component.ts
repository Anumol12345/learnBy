import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServerserviceService } from 'src/app/services/server-service.service';
import {  DomSanitizer, SafeUrl } from "@angular/platform-browser";
import { StateManagerService } from 'src/app/services/state-manager.service';
@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit {
  EditForm: FormGroup;
  submitted: Boolean = false;
  uploadFlag: boolean=false;
  userId: any;
  editData:any;
  name: any;
  selectedFile: any;
  image:any;
 // imgUrl: any;
  //imgurl?: SafeUrl;
  //imagePath: any;
  //url: any
  LinksArray:any=[];
  ProjArray:any=[];
 CollabArray:any=[];
  errorMsg: any;
  errorMsgFlag: boolean =false;
  showLinks:boolean = false;
  showProjs:boolean = false;
  showCollabs:boolean = false;
  constructor(private fb: FormBuilder, private sanitizer: DomSanitizer,
    private state: StateManagerService,private serverService: ServerserviceService,private router: Router,) {
    this.EditForm = this.fb.group({
      uploadedImage:[""],
      email: ["" , [Validators.required, Validators.email]],
      name: ["", Validators.required],
      username: ["", Validators.required],
      location: [""],
      profDesc:[""],
      roles: [""],
      setlink:[""],
      link :[''],
      linkdesc :[""],
      setproj :[""],
      title :[''],
      goal :[""],
      pot :[""],
      setcollab:[""],
      collabtitle:[''],
      collabdesc:[""],
      about: [""],
      
    });

    
   }
  

  ngOnInit(): void {
    this.LoadProfile();
  }

  LoadProfile(){
    if (localStorage.getItem('session.userid')) {
      this.userId = JSON.parse(
        localStorage.getItem('session.userid') || ''
      );
    }
    if (localStorage.getItem('session.name')) {
      this.name = JSON.parse(
        localStorage.getItem('session.name') || ''
      );
    }
 

    this.serverService
    .PostService("/api/login/profile"  ,null, null,null,null)
    .subscribe((data) => {
      console.log(data);

      if(data){
        if(data.error == "TokenExpired"){
          this.serverService.PostService("/api/login/refreshToken"  ,null, null,null,null)
           .subscribe((data) => {
           console.log(data);
           if(data.refreshToken){
             localStorage.setItem("session.key", JSON.stringify(data.refreshToken));
             this.LoadProfile();
           }
          })
          return;
        }
        if(data.profile.length != 0){
          this.editData =data.profile[0];
          this.image = this.editData.image;
          this.EditForm.value.setlink =  false;
          this.EditForm.patchValue({
            uploadedImage :this.image,
            email:this.editData.email,
            name:this.editData.name,
            username:this.editData.username,
            profDesc : this.editData.profileDesc,
            location:this.editData.location,
            roles:this.editData.role,
            about:this.editData.about,
            setlink:(this.editData.setlink === 'true'),
            setproj :(this.editData.setproj === 'true'),
            setcollab:(this.editData.setcollab=== 'true'),
          })
          this.showLinks= this.editData.setlink === "true" ? true : false ;
          this.showProjs= this.editData.setproj === "true" ? true : false ;
          this.showCollabs= this.editData.setcollab === "true" ? true : false ;
         
          
         //console.log(this.EditForm.value.setcollab);
          this.LinksArray  =this.editData.links
          this.ProjArray=this.editData.projects
          this.CollabArray=this.editData.Collabs
        }
        
        
        if(data.profile.length == 0){
          this.EditForm.patchValue({
            email : this.userId,
            name: this.name
        })
        }
        
      }
    });
  }
  onFileChange(event: any) {

    let reader = new FileReader();
    if(event.target.files && event.target.files.length > 0) {
      let file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.image = reader.result; 
        console.log(this.image);
        this.EditForm.get('uploadedImage')?.setValue(this.image);
      };
    }
  

    // this.image = this.sanitizer.bypassSecurityTrustUrl(
    //   window.URL.createObjectURL(this.selectedFile)
     
    // );

     
  
    this.uploadFlag = true;
  
  }
  get f() {
    return this.EditForm.controls;
  }
  onSubmit(){
    this.submitted = true;
    //this.errorMsgFlag = false;
    if (this.EditForm.invalid) {
      return;
    }
    console.log(this.EditForm.value);
    console.log(this.LinksArray)
    console.log(this.ProjArray)
    console.log(this.CollabArray)
    this.serverService
    .PostService("/api/login/addProfile"  ,this.EditForm.value, this.LinksArray , this.ProjArray,this.CollabArray)
    .subscribe((data) => {
      console.log(data);
     if(data){
      if(data.Usererror){
        this.errorMsgFlag = true;
        this.errorMsg  =data.Usererror;
        return;
      }
      if(data.error == "TokenExpired"){
        this.serverService.PostService("/api/login/refreshToken"  ,null, null,null,null)
         .subscribe((data) => {
         console.log(data);
         if(data.refreshToken){
           localStorage.setItem("session.key", JSON.stringify(data.refreshToken));
           this.onSubmit();
         }
        })
        return;
      }
      this.router.navigateByUrl("profile");
      let name = this.EditForm.value.name;
      let profile_image = this.EditForm.value.uploadedImage;

      localStorage.setItem("session.profileImage", JSON.stringify(profile_image));
      localStorage.setItem("session.name", JSON.stringify(name));

      this.state.publishUserimg(profile_image);
      this.state.publishUsername(name);

     }
      

      
    });
  }
  IsCheckedCheck(event:any , id:any){
    if(id == 1){
      if(event.target.checked){
        this.showLinks = true;
      }
      else{
        this.showLinks = false;
      }
    }
    else if(id == 2){
      if(event.target.checked){
        this.showProjs = true;
      }
      else{
        this.showProjs = false;
      }
    }
    else if(id == 3){
      if(event.target.checked){
        this.showCollabs = true;
      }
      else{
        this.showCollabs = false;
      }
    }
    console.log(event.target.checked);


    
  }
  AddLinks(){
   // console.log(this.EditForm.value)
     console.log(this.EditForm.value.link);
     if(this.EditForm.value.link && this.EditForm.value.linkdesc){
      this.LinksArray.push({link:this.EditForm.value.link , desc : this.EditForm.value.linkdesc} );
     }
     
     //this.LinksArray.link = this.EditForm.value.link
     console.log(this.LinksArray);
     
     this.EditForm.patchValue( {'link':null , 'linkdesc':null} );
     
  }
  RemoveLinks(desc:any){
    console.log(this.LinksArray);
    this.LinksArray.forEach((element:any) => {
      if(element.desc == desc){
        console.log(this.LinksArray.indexOf(element));
        this.LinksArray.splice(this.LinksArray.indexOf(element), 1);
      }
    });
   // 
    console.log(desc);
    
    
   
  }
  AddProjs(){
    if(this.EditForm.value.title ){
      this.ProjArray.push({title:this.EditForm.value.title , goal : this.EditForm.value.goal , pot:this.EditForm.value.pot} );
     }
     
     //this.LinksArray.link = this.EditForm.value.link
     console.log(this.ProjArray);
     
     this.EditForm.patchValue( {'title':null , 'goal':null , 'pot':null} );
  }
  RemoveProj(title:any){
    console.log(this.LinksArray);
    this.ProjArray.forEach((element:any) => {
      if(element.title == title){
        console.log(this.ProjArray.indexOf(element));
        this.ProjArray.splice(this.ProjArray.indexOf(element), 1);
      }
    });
  }

  AddCollab(){
    if(this.EditForm.value.collabtitle ){
      this.CollabArray.push({title:this.EditForm.value.collabtitle , desc : this.EditForm.value.collabdesc} );
     }
     
     //this.LinksArray.link = this.EditForm.value.link
     console.log(this.CollabArray);
     
     this.EditForm.patchValue( {'collabtitle':null , 'collabdesc':null , } );
  }
  RemoveCollab(title:any){
    console.log(this.CollabArray);
    this.CollabArray.forEach((element:any) => {
      if(element.title == title){
        console.log(this.CollabArray.indexOf(element));
        this.CollabArray.splice(this.CollabArray.indexOf(element), 1);
      }
    });
  }
}
